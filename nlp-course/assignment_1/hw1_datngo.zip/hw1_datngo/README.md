# homework 1 instructions

## question 2
Type: python3 q2.py --file file_name
By default, file_name is ssn.txt

## question 3
Type: python3 q3.py --file file_name
By default, file_name is pn.txt
